import java.rmi.*;
import java.util.Scanner;

public class VowClient{
	public static void main(String args[]){
		Scanner sc= new Scanner(System.in);
		try{
			String vowServerURL= "rmi://localhost/VowServer";
			VowServerIntf vowServerIntf= (VowServerIntf) Naming.lookup(vowServerURL);
			System.out.println("Enter word:");
			String s= sc.nextLine();
			System.out.println("No of vowels: " + vowServerIntf.vow(s));
		
		}catch(Exception e){
			System.out.println("Exception: "+e);
		}
	}
}
