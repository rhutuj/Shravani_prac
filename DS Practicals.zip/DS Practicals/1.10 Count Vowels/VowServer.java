import java.rmi.*;

public class VowServer{
	public static void main(String args[]){
		try{
			VowServerImpl vowServerImpl= new VowServerImpl();
			Naming.rebind("VowServer", vowServerImpl);
			
		}catch(Exception e){
			System.out.println("Exception :"+e);
		}
	}
}
