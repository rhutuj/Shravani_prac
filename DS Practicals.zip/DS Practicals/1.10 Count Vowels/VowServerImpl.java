import java.rmi.*;
import java.rmi.server.*;

public class VowServerImpl extends UnicastRemoteObject implements VowServerIntf{
	public VowServerImpl() throws RemoteException{}
	public int vow(String s) throws RemoteException{
		int vc=0;
		for(int i=0; i<s.length(); i++){
			char ch= s.charAt(i);
			if(ch=='a' || ch=='e' || ch=='i' || ch=='o' ||ch=='u'){
				vc++;
			}  
		}
		return vc;
	}
}
