import java.rmi.*;

public interface VowServerIntf extends Remote{
	int vow(String s) throws RemoteException;
}
