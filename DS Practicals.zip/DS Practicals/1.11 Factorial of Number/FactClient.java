import java.rmi.*;
import java.util.Scanner;

public class FactClient{
	public static void main(String args[]){
		Scanner sc= new Scanner(System.in);
		try{
			String factServerURL= "rmi://localhost/FactServer";
			FactServerIntf factServerIntf= (FactServerIntf) Naming.lookup(factServerURL);
			System.out.println("Enter no.:");
			int n= sc.nextInt();
			System.out.println("Factorial: " + factServerIntf.fact(n));
		
		}catch(Exception e){
			System.out.println("Exception: "+e);
		}
	}
}
