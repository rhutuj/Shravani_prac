import java.rmi.*;

public class FactServer{
	public static void main(String args[]){
		try{
			FactServerImpl factServerImpl= new FactServerImpl();
			Naming.rebind("FactServer", factServerImpl);
			
		}catch(Exception e){
			System.out.println("Exception :"+e);
		}
	}
}
