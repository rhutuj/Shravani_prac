import java.rmi.*;
import java.rmi.server.*;

public class FactServerImpl extends UnicastRemoteObject implements FactServerIntf{
	public FactServerImpl() throws RemoteException{}
	public int fact(int n) throws RemoteException{
		int res=1;
		for(int i=1; i<=n; i++){
			res=res*i;
		}
		return res;
	}
}
