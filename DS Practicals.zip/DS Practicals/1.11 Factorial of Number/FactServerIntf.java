import java.rmi.*;

public interface FactServerIntf extends Remote{
	int fact(int n) throws RemoteException;
}
