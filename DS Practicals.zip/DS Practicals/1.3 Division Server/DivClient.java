import java.rmi.*;
import java.util.Scanner;

public class DivClient{
	public static void main(String args[]){
		Scanner sc= new Scanner(System.in);
		try{
			String divServerURL = "rmi://localhost/DivServer";
			DivServerIntf divServerIntf= (DivServerIntf) Naming.lookup(divServerURL);
			System.out.println("First No:");
			double d1= sc.nextDouble();
			System.out.println("Second No:");
			double d2= sc.nextDouble();
			System.out.println("Result: "+ divServerIntf.div(d1,d2));
					
		}catch(Exception e){
			System.out.println("Exception: "+e);
		}
	}
}
