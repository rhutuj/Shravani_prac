import java.rmi.*;

public class DivServer{
	public static void main(String args[]){
		try{
			DivServerImpl divServerImpl= new DivServerImpl();
			Naming.rebind("DivServer", divServerImpl);		
		
		}catch(Exception e){
			System.out.println("Exception: "+e);
		}
	}
}
