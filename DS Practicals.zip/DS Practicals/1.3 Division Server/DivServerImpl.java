import java.rmi.*;
import java.rmi.server.*;

public class DivServerImpl extends UnicastRemoteObject implements DivServerIntf{
	public DivServerImpl() throws RemoteException{}
	public double div(double d1, double d2) throws RemoteException{
		if(d2!=0){ return d1/d2; }
		else{ System.out.println("Cannot divide by 0"); }
		
		return d1/d2;
	
	}
	
}
