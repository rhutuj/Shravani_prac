import java.rmi.*;

public interface DivServerIntf extends Remote{
	double div(double d1, double d2) throws RemoteException;
}
