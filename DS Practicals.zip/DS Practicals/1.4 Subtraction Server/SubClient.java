import java.rmi.*;
import java.util.Scanner;

public class SubClient{
	public static void main(String args[]){
		Scanner sc= new Scanner(System.in);
		try{
			String subServerURL= "rmi://localhost/SubServer";
			SubServerIntf subServerIntf= (SubServerIntf) Naming.lookup(subServerURL);
			System.out.println("Enter No.1: ");
			double d1=sc.nextDouble();
			System.out.println("Enter No.2: ");
			double d2=sc.nextDouble();
			System.out.println("Result=" + subServerIntf.sub(d1,d2));
			
		
		}catch(Exception e){
			System.out.println("Exception :"+e);		
		}
	
	}
}
