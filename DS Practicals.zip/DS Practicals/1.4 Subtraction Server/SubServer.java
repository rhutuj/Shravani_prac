import java.rmi.*;

public class SubServer{
	public static void main(String args[]){
		try{
			SubServerImpl subServerImpl = new SubServerImpl();
			Naming.rebind("SubServer", subServerImpl);
		
		}catch(Exception e){
			System.out.println("Exception: "+e);
		}
	}
}
