import java.rmi.*;
import java.rmi.server.*;

public class SubServerImpl extends UnicastRemoteObject implements SubServerIntf{
	public SubServerImpl() throws RemoteException{}
	public double sub(double d1, double d2) throws RemoteException{
		return d1-d2;
	}
}
