import java.rmi.*;
import java.util.Scanner;

public class PowClient{
	public static void main(String args[]){
		Scanner sc= new Scanner(System.in);
		try{
			String powServerURL= "rmi://localhost/PowServer";
			PowServerIntf powServerIntf = (PowServerIntf) Naming.lookup(powServerURL);
			System.out.println("Enter power");
			double n= sc.nextDouble();
			System.out.println("Result=" + powServerIntf.pow(n));			
		
	
		}catch(Exception e){
			System.out.println("Exception: "+e);
		}
	}
}
