import java.rmi.*;
import java.rmi.server.*;

public class PowServerImpl extends UnicastRemoteObject implements PowServerIntf{
	public PowServerImpl() throws RemoteException{}
	public double pow(double n){
		double result= Math.pow(2, n);
		return result;	
	}
}
