import java.rmi.*;

public interface PowServerIntf extends Remote{
	public double pow(double n) throws RemoteException;
}
