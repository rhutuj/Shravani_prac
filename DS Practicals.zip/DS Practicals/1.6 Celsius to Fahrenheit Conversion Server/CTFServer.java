import java.rmi.*;

public class CTFServer{
	public static void main(String args[]){
		try{
			CTFServerImpl ctfServerImpl= new CTFServerImpl();
			Naming.rebind("CTFServer", ctfServerImpl);
			
		}catch(Exception e){
			System.out.println("Exception :"+e);
		}
	}
}
