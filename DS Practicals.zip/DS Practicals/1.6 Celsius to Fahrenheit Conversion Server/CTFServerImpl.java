import java.rmi.*;
import java.rmi.server.*;

public class CTFServerImpl extends UnicastRemoteObject implements CTFServerIntf{
	public CTFServerImpl() throws RemoteException{}
	public double ctf(double n) throws RemoteException{
		double result= (n*9/5)+32;
		return result;
	}
}
