import java.rmi.*;

public interface CTFServerIntf extends Remote{
	double ctf(double n) throws RemoteException;
}
