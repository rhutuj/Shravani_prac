import java.rmi.*;
import java.util.Scanner;

public class MTKClient{
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		try{
			String mtkServerURL= "rmi://localhost/MTKServer";
			MTKServerIntf mtkServerIntf = (MTKServerIntf) Naming.lookup(mtkServerURL);
			System.out.println("Enter miles: ");
			double n= sc.nextDouble();
			System.out.println("KMs: " + mtkServerIntf.mtk(n));
		
		}catch(Exception e){
			System.out.println("Exception " + e);
		}
	}
}
