import java.rmi.*;

public class MTKServer{
	public static void main(String args[]){
		try{
			MTKServerImpl mtkServerImpl = new MTKServerImpl();
			Naming.rebind("MTKServer", mtkServerImpl);
		
		}catch(Exception e){
			System.out.println("Exception: " + e);
		}
	}
}
