import java.rmi.*;
import java.rmi.server.*;

public class MTKServerImpl extends UnicastRemoteObject implements MTKServerIntf{
	public MTKServerImpl() throws RemoteException{}
	public double mtk(double n) throws RemoteException{
		double result= n*1.609;
		return result;
	}
}
