import java.rmi.*;

public interface MTKServerIntf extends Remote{
	public double mtk(double n) throws RemoteException;
}
