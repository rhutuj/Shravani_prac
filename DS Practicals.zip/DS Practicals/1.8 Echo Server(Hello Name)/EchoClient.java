import java.rmi.*;
import java.util.Scanner;

public class EchoClient{
	public static void main(String args[]){
		Scanner sc= new Scanner(System.in);
		try{
			String echoServerURL= "rmi://localhost/EchoServer";
			EchoServerIntf echoServerIntf= (EchoServerIntf) Naming.lookup(echoServerURL);
			System.out.println("Enter Name");
			String s= sc.nextLine();
			System.out.println(echoServerIntf.echo(s));
		
		}catch(Exception e){
			System.out.println("Exception: "+e);
		}
	}
}
