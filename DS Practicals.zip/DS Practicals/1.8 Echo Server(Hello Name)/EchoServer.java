import java.rmi.*;

public class EchoServer{
	public static void main(String args[]){
		try{
			EchoServerImpl echoServerImpl= new EchoServerImpl();
			Naming.rebind("EchoServer", echoServerImpl);
			
		}catch(Exception e){
			System.out.println("Exception :"+e);
		}
	}
}
