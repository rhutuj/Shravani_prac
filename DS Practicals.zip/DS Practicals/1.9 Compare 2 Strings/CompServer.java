import java.rmi.*;

public class CompServer{
	public static void main(String args[]){
		try{
			CompServerImpl compServerImpl= new CompServerImpl();
			Naming.rebind("CompServer", compServerImpl);
			
		}catch(Exception e){
			System.out.println("Exception :"+e);
		}
	}
}
