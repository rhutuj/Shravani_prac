import java.rmi.*;
import java.rmi.server.*;

public class CompServerImpl extends UnicastRemoteObject implements CompServerIntf{
	public CompServerImpl() throws RemoteException{}
	public String comp(String s1, String s2) throws RemoteException{
		int compresult= s1.compareTo(s2);
		if(compresult >0 ) { return s1; }
		else if( compresult<0 ) { return s2; }
		return s1;
	}
}
