import java.rmi.*;

public interface CompServerIntf extends Remote{
	String comp (String s1, String s2) throws RemoteException;
}
