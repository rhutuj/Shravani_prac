import java.util.*;
import mpi.*;

public class ArrayAvg{
	public static void main(String[] args){
		MPI.Init(args);
		
		int rank= MPI.COMM_WORLD.Rank();
		int size= MPI.COMM_WORLD.Size();
		
		int unitsize=5;
		int root=0;
		int send_buffer[]= new int [unitsize*size];
		int receive_buffer[]= new int [unitsize];
		int new_receive_buffer[] = new int [size];
		
		if(rank==root){
			int total_elements= unitsize*size;
			Random rand = new Random();
			System.out.println("Elements: ");
			for(int i=0; i<total_elements; i++){
				send_buffer[i]= rand.nextInt(100); //0 to 99
				System.out.println("Element " + i + " is " + send_buffer[i]);				
			}
		}
		
		MPI.COMM_WORLD.Scatter(
		send_buffer,
		0,
		unitsize,
		MPI.INT,
		receive_buffer,
		0,
		unitsize,
		MPI.INT,
		root
		);
		
		int local_sum=0;
		for(int i=0; i<unitsize; i++){
			local_sum+=receive_buffer[i]; 
		}
		receive_buffer[0]= (int) (local_sum/unitsize);
		
		System.out.println("Average at process " + rank + " = " + receive_buffer[0]);
		
		
		MPI.COMM_WORLD.Gather(
		receive_buffer,
		0,
		1,
		MPI.INT,
		new_receive_buffer,
		0,
		1,
		MPI.INT,
		root
		);
		
		
		if(rank==0){
			int sum1=0;
			for(int i=0; i<size; i++){
				sum1+=new_receive_buffer[i];
			}
			double final_avg= (double) sum1/size;
			System.out.println("Final Average: " + final_avg);
		}
		
		MPI.Finalize();
	}
}
