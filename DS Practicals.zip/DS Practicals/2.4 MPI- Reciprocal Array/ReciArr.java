import java.util.*;
import mpi.*;

public class ReciArr{
	public static void main(String[] args){
		MPI.Init(args);
		
		int rank= MPI.COMM_WORLD.Rank();
		int size= MPI.COMM_WORLD.Size();
		
		int unitsize=1;
		int root=0;
		float send_buffer[] = new float [unitsize*size];
		float receive_buffer[] = new float [unitsize];
		float new_receive_buffer[]= new float[size];
		
		if(rank==root){
			int total_elements= unitsize*size;
			System.out.println("Array Elements: ");
			for(int i=0; i<total_elements; i++){
				send_buffer[i]= i+1;
				System.out.println("Element " + i + " is " + (i+1));
			}
		}
		
		//Scatter
		MPI.COMM_WORLD.Scatter(
		send_buffer,
		0, 
		unitsize,
		MPI.FLOAT,
		receive_buffer,
		0,
		unitsize,
		MPI.FLOAT,
		root
		);
		
		
		receive_buffer[0]= (float) 1.0f/receive_buffer[0];
		System.out.println("Reciprocal at " + rank + " = " + receive_buffer[0]);
		
		//Gather
		MPI.COMM_WORLD.Gather(
		receive_buffer,
		0,
		1,
		MPI.FLOAT,
		new_receive_buffer,
		0,
		1,
		MPI.FLOAT,
		root
		);
		
		if(rank==root){
			System.out.println("Final Array: ");
			for(int i=0; i<size; i++){
				System.out.print(new_receive_buffer[i]+ " ");
			}
		}
		MPI.Finalize();
	
	}
}
