import UpperModule.UpperPOA;

class UpperImpl extends UpperPOA {
    UpperImpl() {
        super();
        System.out.println("Upper Object Created");
    }

    public String upper_string(String name) {
        return "Server Send: " + name.toUpperCase();
    }
}
