import java.util.*;

class TokenRingAlgo {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the number of nodes: ");
        int n = sc.nextInt();

        // Decides the number of nodes forming the ring
        int token = 0;

        for (int i = 0; i < n; i++)
            System.out.print(" " + i);
        System.out.println(" " + 0);

        try {
            int choice=0;
            do {
                System.out.print("Enter sender: ");
                int s = sc.nextInt();
                System.out.print("Enter receiver: ");
                int r = sc.nextInt();
                System.out.print("Enter Data: ");
                String d = sc.next();

                System.out.print("Token passing:");
                 //current token not equal to sender, increment i by 1 and j by j+1%n
         
                for(int i=token; i<s; i++){
                	System.out.print(" "+i+"->");
                }
                System.out.println(" "+s);
                System.out.println("Sender:"+s+" Sending Data: "+d);
          

                // start forwarding from node after sender until it becomes equal to receiver and increment  by i+1%n
                for(int i=s; i!=r; i=(i+1)%n){
                	System.out.println("Data: "+d+" Forwarded by: "+i);
                }
                System.out.println("Receiver: "+r+" Received the data: "+d);
                token = s;
                System.out.println("Do you want to continue?(1/0)");
                choice=sc.nextInt();
                
            }while(choice==1);
        } catch (Exception e) {
            System.out.println("Error occurred: " + e.getMessage());
        }
    }
}
